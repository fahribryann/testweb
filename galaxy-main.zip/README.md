# Hướng dẫn Remake Code (file: script.js)

Tất cả chỉnh sửa bạn cần làm đều nằm trong file script.js. Làm theo các bước dưới đây để tùy biến lại project theo ý bạn:

---

## 1. 🖼️ Thêm Ảnh ở dòng **87**
- Tới dòng **87** trong script.js
- thay length tương ứng với số ảnh ở folder images

---

## 2. 📝 Thay Text ở dòng **614**
- Tìm tới dòng **614** trong script.js
- Thay nội dung văn bản thành bất kỳ nội dung nào bạn muốn.
- Ví dụ: thay tiêu đề, mô tả, lời chào, v.v.

---

## 3. 📝 Thay Text ở dòng **823**
- Tìm tới dòng **823** trong  script.js
- Thêm các link nhạc tùy ae.


